
import { Link } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

interface ToolCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  path: string;
  gradientClass: string;
}

const ToolCard = ({ title, description, icon, path, gradientClass }: ToolCardProps) => {
  return (
    <Card className="overflow-hidden border-0 shadow-md transition-all duration-300 hover:shadow-lg">
      <div className={`h-2 tool-gradient ${gradientClass}`} />
      <CardContent className="p-6">
        <div className="mb-4">
          {icon}
        </div>
        <h3 className="text-xl font-bold mb-2">{title}</h3>
        <p className="text-gray-600 mb-6">{description}</p>
        <Link to={path}>
          <Button className={`w-full text-white tool-gradient ${gradientClass}`}>
            Try {title}
          </Button>
        </Link>
      </CardContent>
    </Card>
  );
};

export default ToolCard;
