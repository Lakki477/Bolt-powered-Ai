
import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";
import { Download, Loader } from 'lucide-react';

interface ResultDisplayProps {
  result: string;
  isLoading?: boolean;
  type: 'shayari' | 'bio' | 'hashtag' | 'image' | 'video';
}

const ResultDisplay = ({ result, isLoading = false, type }: ResultDisplayProps) => {
  const [copied, setCopied] = useState(false);
  const [downloading, setDownloading] = useState(false);
  
  const handleCopy = () => {
    navigator.clipboard.writeText(result);
    setCopied(true);
    toast.success("Copied to clipboard!");
    setTimeout(() => setCopied(false), 2000);
  };
  
  const handleDownload = async () => {
    if (type !== 'image') return;
    
    setDownloading(true);
    
    try {
      const response = await fetch(result);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `generated-image-${Date.now()}.jpg`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      toast.success("Image downloaded successfully!");
    } catch (error) {
      console.error('Error downloading image:', error);
      toast.error("Failed to download image. Please try again.");
    } finally {
      setDownloading(false);
    }
  };
  
  // Map type to color for the border
  const borderColorClass = {
    shayari: 'border-t-purple-500',
    bio: 'border-t-cyan-500',
    hashtag: 'border-t-orange-500',
    image: 'border-t-emerald-500',
    video: 'border-t-blue-500',
  }[type];
  
  if (isLoading) {
    return (
      <Card className={`mt-8 border-t-4 ${borderColorClass} shadow-md`}>
        <CardContent className="p-6">
          <div className="flex flex-col space-y-3">
            <div className="h-4 bg-gray-200 rounded animate-pulse"></div>
            <div className="h-4 bg-gray-200 rounded animate-pulse"></div>
            <div className="h-4 bg-gray-200 rounded animate-pulse"></div>
            <div className="h-4 w-2/3 bg-gray-200 rounded animate-pulse"></div>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  if (!result) {
    return null;
  }
  
  // Special rendering for image type
  if (type === 'image' && result) {
    return (
      <Card className={`mt-8 border-t-4 ${borderColorClass} shadow-md overflow-hidden`}>
        <CardContent className="p-0">
          <div className="relative">
            <img src={result} alt="Generated image" className="w-full h-auto" />
            <div className="absolute bottom-4 right-4 flex space-x-2">
              <Button 
                onClick={handleCopy} 
                variant="secondary"
                className="bg-white/80 backdrop-blur-sm text-gray-800 hover:bg-white"
              >
                {copied ? "Copied!" : "Copy Link"}
              </Button>
              <Button 
                onClick={handleDownload} 
                variant="secondary"
                className="bg-white/80 backdrop-blur-sm text-gray-800 hover:bg-white group"
                disabled={downloading}
              >
                {downloading ? (
                  <Loader className="h-4 w-4 animate-spin mr-1" />
                ) : (
                  <Download className="h-4 w-4 mr-1 group-hover:animate-bounce" />
                )}
                Download
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card className={`mt-8 border-t-4 ${borderColorClass} shadow-md`}>
      <CardContent className="p-6">
        <div className="whitespace-pre-wrap">
          {type === 'hashtag' ? (
            <div className="flex flex-wrap gap-2">
              {result.split(' ').map((tag, index) => (
                <span key={index} className="bg-gray-100 px-3 py-1 rounded-full text-gray-700">
                  {tag}
                </span>
              ))}
            </div>
          ) : type === 'video' ? (
            <div className="markdown prose max-w-none text-gray-800">
              {result.split('\n').map((line, index) => {
                // Style headings (lines with ** at beginning and end)
                if (line.startsWith('**') && line.endsWith('**')) {
                  return <h3 key={index} className="font-bold text-lg mt-3 mb-2">{line.replace(/\*\*/g, '')}</h3>;
                }
                // Style section headings (lines with [ and ] at beginning)
                else if (line.match(/^\[.*\]/)) {
                  return <h4 key={index} className="font-semibold text-blue-700 mt-4">{line}</h4>;
                }
                // Style lists
                else if (line.match(/^\d+\./)) {
                  return <div key={index} className="ml-5 list-item list-decimal">{line}</div>;
                }
                // Style section titles
                else if (line.match(/^Section \d+:/)) {
                  return <h4 key={index} className="font-semibold mt-3">{line}</h4>;
                }
                // Style part titles
                else if (line.match(/^Part \d+:/)) {
                  return <h4 key={index} className="font-semibold mt-3">{line}</h4>;
                }
                // Empty lines become breaks
                else if (line === '') {
                  return <br key={index} />;
                }
                // Regular lines
                else {
                  return <p key={index} className="my-1">{line}</p>;
                }
              })}
            </div>
          ) : (
            <p className="text-gray-800">{result}</p>
          )}
        </div>
        <div className="flex justify-end mt-4">
          <Button
            onClick={handleCopy}
            variant="outline"
            className="ml-auto"
          >
            {copied ? "Copied!" : "Copy"}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default ResultDisplay;
