
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import ShayariGenerator from "./pages/ShayariGenerator";
import BioGenerator from "./pages/BioGenerator";
import HashtagGenerator from "./pages/HashtagGenerator";
import ImageGenerator from "./pages/ImageGenerator";
import VideoScriptGenerator from "./pages/VideoScriptGenerator";
import ThumbnailGenerator from "./pages/ThumbnailGenerator";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/shayari" element={<ShayariGenerator />} />
          <Route path="/bio" element={<BioGenerator />} />
          <Route path="/hashtag" element={<HashtagGenerator />} />
          <Route path="/image" element={<ImageGenerator />} />
          <Route path="/video-script" element={<VideoScriptGenerator />} />
          <Route path="/thumbnail" element={<ThumbnailGenerator />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
