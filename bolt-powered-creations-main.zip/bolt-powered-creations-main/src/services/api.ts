
// This is a mock API service for demonstration purposes
// In a real app, these would connect to actual APIs like OpenAI

// For demonstration, we're using timeout to simulate API calls
const mockApiCall = <T>(data: T, delay = 1500): Promise<T> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(data);
    }, delay);
  });
};

export const generateShayari = async (theme: string): Promise<string> => {
  console.log("Generating shayari with theme:", theme);
  
  // Mock response - in a real app, this would call OpenAI or another API
  const sampleShayaris = [
    `किसी के प्यार में हम भी ${theme} हो गए,\nक्या से क्या हम भी ${theme} में हो गए।\nवो अब भी याद करते हैं हमें बहुत,\nमगर हम तो उनके लिए खाक हो गए।`,
    `${theme} की बातें करते हैं, ${theme} से लगाव रखते हैं,\nहम तो बस उनके ख्यालों में अपना दिल बहलाते हैं।\n${theme} की खुशबू हवाओं में है, ${theme} का रंग फिजाओं में है,\nहम तो बस उनके इंतज़ार में दिन गुज़ारते हैं।`,
    `${theme} में डूबे हुए हैं हम, ${theme} को महसूस करते हैं,\nतुम्हारी यादों के सहारे हम अपना वक़्त गुज़ारते हैं।\n${theme} का मौसम है, ${theme} की बारिश है,\nहम तुम्हारे बिना भी जीने की कोशिश करते हैं।`
  ];
  
  const randomIndex = Math.floor(Math.random() * sampleShayaris.length);
  return mockApiCall(sampleShayaris[randomIndex]);
};

export const generateBio = async (name: string, profession: string, interests: string): Promise<string> => {
  console.log("Generating bio for:", { name, profession, interests });
  
  // Mock response
  const sampleBios = [
    `${name} | ${profession} | ${interests} enthusiast\n\nHelping brands tell their stories through creative design and strategic thinking. Passionate about ${interests} and always looking for new opportunities to grow.`,
    `Meet ${name}: A passionate ${profession} with a keen interest in ${interests}. Delivering exceptional results through creativity and dedication. Let's connect and create something amazing together!`,
    `${name} • ${profession}\nCreative thinker and problem solver specializing in ${interests}. Constantly learning and evolving in the ever-changing world of ${profession}. Let's create impact together!`
  ];
  
  const randomIndex = Math.floor(Math.random() * sampleBios.length);
  return mockApiCall(sampleBios[randomIndex]);
};

export const generateHashtags = async (topic: string): Promise<string> => {
  console.log("Generating hashtags for topic:", topic);
  
  // Mock response
  const sampleHashtags = [
    `#${topic} #${topic}Love #${topic}Life #Trending #${topic}Vibes #${topic}Community #${topic}Goals #${topic}Inspiration #${topic}Journey #LifeStyle`,
    `#${topic}Expert #${topic}Tips #${topic}Hacks #${topic}101 #Learn${topic} #${topic}Daily #${topic}Lovers #${topic}World #${topic}Time #${topic}Moments`,
    `#${topic}Gram #${topic}Photography #${topic}Art #Creative${topic} #${topic}Design #${topic}Style #${topic}Fashion #${topic}Trending #${topic}Viral #${topic}TikTok`
  ];
  
  const randomIndex = Math.floor(Math.random() * sampleHashtags.length);
  return mockApiCall(sampleHashtags[randomIndex]);
};

export const generateImage = async (prompt: string, size: string = "800x600", apiKey: string): Promise<string> => {
  console.log("Generating image with prompt:", prompt, "size:", size);
  
  // Log that we received an API key (don't log the actual key for security)
  console.log("Using provided API key for image generation");
  
  // In a real implementation, this would use the OpenAI API with the provided API key
  // For demo purposes, we'll use Unsplash to generate a relevant image based on the prompt keywords
  
  // For now, this is a mock that simulates what would happen with OpenAI
  // const response = await fetch("https://api.openai.com/v1/images/generations", {
  //   method: "POST",
  //   headers: {
  //     "Content-Type": "application/json",
  //     "Authorization": `Bearer ${apiKey}`
  //   },
  //   body: JSON.stringify({
  //     prompt,
  //     n: 1,
  //     size,
  //     response_format: "url"
  //   })
  // });
  
  // Mock response with more relevant placeholder images based on prompt keywords
  const keywords = prompt.toLowerCase();
  let category = "technology";
  
  if (keywords.includes("nature") || keywords.includes("mountain") || keywords.includes("forest") || keywords.includes("beach") || keywords.includes("landscape")) {
    category = "nature";
  } else if (keywords.includes("city") || keywords.includes("urban") || keywords.includes("building")) {
    category = "city";
  } else if (keywords.includes("person") || keywords.includes("people") || keywords.includes("portrait")) {
    category = "people";
  } else if (keywords.includes("food") || keywords.includes("drink") || keywords.includes("meal")) {
    category = "food";
  } else if (keywords.includes("dog") || keywords.includes("cat") || keywords.includes("pet") || keywords.includes("animal") || keywords.includes("goat")) {
    category = "animals";
  } else if (keywords.includes("art") || keywords.includes("painting") || keywords.includes("drawing")) {
    category = "art";
  }
  
  // Simulate loading time based on size (larger images take longer)
  const delay = size === "1024x1024" ? 2500 : 
               size === "1024x768" ? 2200 : 
               size === "800x600" ? 1800 : 1500;
  
  // Add a small random number to the URL to prevent browser caching
  const cacheBuster = Date.now();
  return mockApiCall(`https://source.unsplash.com/random/${size}/?${category}&cb=${cacheBuster}`, delay);
};

export const generateVideoScript = async (topic: string, platform: string, scriptType: string): Promise<string> => {
  console.log("Generating video script for:", { topic, platform, scriptType });
  
  // Mock response based on platform and length
  const shortScripts = {
    youtube: `**YOUTUBE SHORT SCRIPT: ${topic.toUpperCase()}**\n\nHEY YOUTUBE! Today we're diving into ${topic}!\n\n[HOOK] Did you know that ${topic} can change the way you think about everything?\n\n[MAIN POINT 1] First, let's talk about why ${topic} matters...\n\n[MAIN POINT 2] The most surprising thing about ${topic} is...\n\n[CALL TO ACTION] If you found this helpful, smash that like button and subscribe for more content like this!\n\n#shorts #${topic.replace(/\s+/g, '')}`,
    
    instagram: `**INSTAGRAM REEL SCRIPT: ${topic.toUpperCase()}**\n\n[VISUAL: Face to camera with energetic intro]\n\nTap save if you've been struggling with ${topic}!\n\n[VISUAL: Quick transition to key points]\n\nHere are 3 quick facts about ${topic} that will blow your mind:\n1. ...\n2. ...\n3. ...\n\n[VISUAL: Call to action screen]\n\nFollow for more tips on ${topic} and drop a comment if this helped!\n\n#instareels #${topic.replace(/\s+/g, '')}`,
    
    facebook: `**FACEBOOK SHORT VIDEO SCRIPT: ${topic.toUpperCase()}**\n\nHey Facebook friends! Quick tip about ${topic}...\n\n[MAIN CONTENT] The one thing most people get wrong about ${topic} is...\n\nHere's what you should do instead...\n\n[CONCLUSION] Let me know in the comments if you found this helpful!\n\n#facebookvideo #${topic.replace(/\s+/g, '')}`
  };
  
  const longScripts = {
    youtube: `**YOUTUBE LONG-FORM SCRIPT: ${topic.toUpperCase()}**\n\n[INTRO - 30 SEC]\nHey everyone, welcome back to the channel! Today we're diving deep into ${topic}.\n\n[HOOK - 20 SEC]\nIf you've ever wondered about ${topic}, you're in for a treat. This video will cover everything you need to know.\n\n[CHANNEL INTRO/BRANDING - 10 SEC]\n\n[OVERVIEW - 30 SEC]\nIn this video, we'll cover:\n1. What is ${topic}?\n2. Why ${topic} matters\n3. How to implement ${topic} in your life\n4. Common misconceptions about ${topic}\n5. Resources to learn more\n\n[MAIN CONTENT - 3 MIN]\n\nSection 1: Introduction to ${topic}\n- Definition and background\n- Historical context\n- Why it's relevant today\n\nSection 2: Key aspects of ${topic}\n- Important components\n- How it works\n- Real-world examples\n\nSection 3: Implementation strategies\n- Step-by-step guide\n- Tools and resources\n- Common challenges and solutions\n\n[CONCLUSION - 30 SEC]\nTo summarize, we've covered what ${topic} is, why it matters, and how you can use it in your own life or work.\n\n[CALL TO ACTION - 20 SEC]\nIf you found this video helpful, please hit that like button and subscribe for more content. Drop a comment below with your thoughts or questions about ${topic}.\n\n#${topic.replace(/\s+/g, '')} #tutorial #guide`,
    
    instagram: `**INSTAGRAM IGTV SCRIPT: ${topic.toUpperCase()}**\n\n[INTRO - 20 SEC]\nHey Instagram! Today I'm sharing a complete guide on ${topic}.\n\n[MAIN CONTENT - 3-4 MIN]\n\nPart 1: The Basics of ${topic}\n- What you need to know\n- Why it matters to you\n- Quick background\n\nPart 2: Practical Applications\n- How to use ${topic} in daily life\n- Examples and demonstrations\n- Before and after results\n\nPart 3: Expert Tips\n- Advanced strategies\n- Things to avoid\n- Resources I recommend\n\n[CONCLUSION - 30 SEC]\nI hope this gives you a better understanding of ${topic}! If you have questions, drop them below.\n\n[CALL TO ACTION]\nSave this post for later and tag someone who needs to see this!\n\n#${topic.replace(/\s+/g, '')} #IGTVtutorial`,
    
    facebook: `**FACEBOOK LONG-FORM VIDEO SCRIPT: ${topic.toUpperCase()}**\n\n[GREETING - 20 SEC]\nHey everyone! Thanks for joining me today as we talk about ${topic}.\n\n[INTRODUCTION - 40 SEC]\nMany of you have been asking about ${topic}, and I wanted to create a comprehensive guide to help you understand it better.\n\n[MAIN CONTENT - 3-4 MIN]\n\nSection 1: Understanding ${topic}\n- Definition and importance\n- Common misconceptions\n- Who needs to know about this\n\nSection 2: Practical Guide\n- Step-by-step approach\n- Tools and resources\n- Examples and case studies\n\nSection 3: Q&A\n- Answering common questions from previous posts\n- Addressing misconceptions\n- Additional resources\n\n[CONCLUSION - 30 SEC]\nI hope this video has been helpful in understanding ${topic} better. Remember that mastering this takes time and practice.\n\n[COMMUNITY ENGAGEMENT - 20 SEC]\nI'd love to hear your experiences with ${topic} in the comments below. If you found this helpful, please share it with friends who might benefit.\n\n#${topic.replace(/\s+/g, '')} #facebooklive #tutorial`
  };
  
  const scripts = scriptType === 'short' ? shortScripts : longScripts;
  return mockApiCall(scripts[platform as keyof typeof scripts]);
};

export const generateThumbnail = async (prompt: string, platform: string, size: string, apiKey?: string): Promise<string> => {
  console.log("Generating thumbnail with prompt:", prompt, "platform:", platform, "size:", size);
  
  // In a real implementation, you would use the apiKey to make a call to the OpenAI API
  // For now, we'll just log that we received an API key (without logging the actual key)
  if (apiKey) {
    console.log("API key provided, would use it to call OpenAI API in a production environment");
  }
  
  // Extract dimensions from the size string (e.g., "1280x720")
  const dimensions = size.split('x');
  const width = dimensions[0];
  const height = dimensions[1];
  
  // Mock response with placeholder images specific to each platform and prompt keywords
  const keywords = prompt.toLowerCase();
  let category = "thumbnail";
  
  if (keywords.includes("tech") || keywords.includes("computer") || keywords.includes("digital")) {
    category = "technology,thumbnail";
  } else if (keywords.includes("travel") || keywords.includes("adventure")) {
    category = "travel,thumbnail";
  } else if (keywords.includes("food") || keywords.includes("recipe") || keywords.includes("cooking")) {
    category = "food,thumbnail";
  } else if (keywords.includes("fitness") || keywords.includes("workout") || keywords.includes("exercise")) {
    category = "fitness,thumbnail";
  }
  
  const platformPrefix = platform === 'youtube' ? 'youtube,' : 
                         platform === 'instagram' ? 'instagram,' : 
                         'facebook,';
  
  return mockApiCall(`https://source.unsplash.com/random/${width}x${height}/?${platformPrefix}${category}`);
};
