
import { useState } from 'react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import ResultDisplay from '@/components/ResultDisplay';
import { generateBio } from '@/services/api';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from "sonner";

const BioGenerator = () => {
  const [name, setName] = useState('');
  const [profession, setProfession] = useState('');
  const [interests, setInterests] = useState('');
  const [result, setResult] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name.trim() || !profession.trim() || !interests.trim()) {
      toast.error("Please fill all fields to generate a bio");
      return;
    }
    
    setIsLoading(true);
    
    try {
      const bio = await generateBio(name, profession, interests);
      setResult(bio);
    } catch (error) {
      console.error('Error generating bio:', error);
      toast.error("Failed to generate bio. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      
      <main className="flex-1 py-12 bg-gradient-to-b from-cyan-50 to-white">
        <div className="container px-4 md:px-6">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-8">
              <h1 className="text-3xl font-bold text-gray-900">Bio Generator</h1>
              <p className="text-gray-600 mt-2">
                Create professional and creative bios for your social media profiles.
              </p>
            </div>
            
            <Card className="border shadow-md">
              <CardHeader className="bg-gradient-to-r from-cyan-500 to-cyan-700 text-white">
                <CardTitle>Generate a Bio</CardTitle>
                <CardDescription className="text-white/90">
                  Enter your details to create a customized bio
                </CardDescription>
              </CardHeader>
              <CardContent className="pt-6">
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Input
                      placeholder="Your Name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full"
                      disabled={isLoading}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Input
                      placeholder="Your Profession"
                      value={profession}
                      onChange={(e) => setProfession(e.target.value)}
                      className="w-full"
                      disabled={isLoading}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Input
                      placeholder="Your Interests (e.g., photography, travel, cooking)"
                      value={interests}
                      onChange={(e) => setInterests(e.target.value)}
                      className="w-full"
                      disabled={isLoading}
                    />
                  </div>
                  
                  <Button 
                    type="submit" 
                    className="w-full bg-gradient-to-r from-cyan-500 to-cyan-700 text-white hover:from-cyan-600 hover:to-cyan-800"
                    disabled={isLoading}
                  >
                    {isLoading ? 'Generating...' : 'Generate Bio'}
                  </Button>
                </form>
              </CardContent>
            </Card>
            
            <ResultDisplay 
              result={result} 
              isLoading={isLoading}
              type="bio"
            />
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default BioGenerator;
