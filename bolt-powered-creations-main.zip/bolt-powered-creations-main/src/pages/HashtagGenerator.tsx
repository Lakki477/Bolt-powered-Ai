
import { useState } from 'react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import ResultDisplay from '@/components/ResultDisplay';
import { generateHashtags } from '@/services/api';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from "sonner";

const HashtagGenerator = () => {
  const [topic, setTopic] = useState('');
  const [result, setResult] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!topic.trim()) {
      toast.error("Please enter a topic for hashtag generation");
      return;
    }
    
    setIsLoading(true);
    
    try {
      const hashtags = await generateHashtags(topic);
      setResult(hashtags);
    } catch (error) {
      console.error('Error generating hashtags:', error);
      toast.error("Failed to generate hashtags. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      
      <main className="flex-1 py-12 bg-gradient-to-b from-orange-50 to-white">
        <div className="container px-4 md:px-6">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-8">
              <h1 className="text-3xl font-bold text-gray-900">Hashtag Generator</h1>
              <p className="text-gray-600 mt-2">
                Find the perfect hashtags to increase your content's visibility.
              </p>
            </div>
            
            <Card className="border shadow-md">
              <CardHeader className="bg-gradient-to-r from-orange-500 to-orange-700 text-white">
                <CardTitle>Generate Hashtags</CardTitle>
                <CardDescription className="text-white/90">
                  Enter a topic to generate relevant hashtags
                </CardDescription>
              </CardHeader>
              <CardContent className="pt-6">
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Input
                      placeholder="Enter topic (e.g., fitness, travel, food)"
                      value={topic}
                      onChange={(e) => setTopic(e.target.value)}
                      className="w-full"
                      disabled={isLoading}
                    />
                  </div>
                  
                  <Button 
                    type="submit" 
                    className="w-full bg-gradient-to-r from-orange-500 to-orange-700 text-white hover:from-orange-600 hover:to-orange-800"
                    disabled={isLoading}
                  >
                    {isLoading ? 'Generating...' : 'Generate Hashtags'}
                  </Button>
                </form>
              </CardContent>
            </Card>
            
            <ResultDisplay 
              result={result} 
              isLoading={isLoading}
              type="hashtag"
            />
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default HashtagGenerator;
