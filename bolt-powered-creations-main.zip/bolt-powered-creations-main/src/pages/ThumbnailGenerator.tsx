
import { useState } from 'react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import ResultDisplay from '@/components/ResultDisplay';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from "sonner";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Image, Key, Loader } from 'lucide-react';
import { generateThumbnail } from '@/services/api';
import { Input } from '@/components/ui/input';

const ThumbnailGenerator = () => {
  const [prompt, setPrompt] = useState('');
  const [platform, setPlatform] = useState('youtube');
  const [size, setSize] = useState('1280x720');
  const [result, setResult] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [apiKey, setApiKey] = useState('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');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!prompt.trim()) {
      toast.error("Please enter a description for your thumbnail");
      return;
    }

    if (!apiKey.trim()) {
      toast.error("Please enter your API key");
      return;
    }
    
    setIsLoading(true);
    
    try {
      // We pass the API key to the generateThumbnail function
      const imageUrl = await generateThumbnail(prompt, platform, size, apiKey);
      setResult(imageUrl);
      toast.success("Thumbnail generated successfully!");
    } catch (error) {
      console.error('Error generating thumbnail:', error);
      toast.error("Failed to generate thumbnail. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  // Size options based on selected platform
  const sizeOptions = {
    youtube: [
      { value: '1280x720', label: 'YouTube Standard (1280x720)' },
      { value: '2560x1440', label: 'YouTube HD (2560x1440)' },
    ],
    facebook: [
      { value: '1200x630', label: 'Facebook Post (1200x630)' },
      { value: '820x312', label: 'Facebook Cover (820x312)' },
    ],
    instagram: [
      { value: '1080x1080', label: 'Instagram Square (1080x1080)' },
      { value: '1080x1350', label: 'Instagram Portrait (1080x1350)' },
      { value: '1080x608', label: 'Instagram Landscape (1080x608)' },
    ],
  };

  // When platform changes, set the first size option as default
  const handlePlatformChange = (value: string) => {
    setPlatform(value);
    setSize(sizeOptions[value as keyof typeof sizeOptions][0].value);
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      
      <main className="flex-1 py-12 bg-gradient-to-b from-purple-50 to-white">
        <div className="container px-4 md:px-6">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-8">
              <h1 className="text-3xl font-bold text-gray-900">Thumbnail Generator</h1>
              <p className="text-gray-600 mt-2">
                Create eye-catching thumbnails for YouTube, Instagram, or Facebook.
              </p>
            </div>
            
            <Card className="border shadow-md">
              <CardHeader className="bg-gradient-to-r from-purple-500 to-purple-700 text-white">
                <CardTitle className="flex items-center gap-2">
                  <Image className="h-6 w-6" />
                  Create Thumbnail
                </CardTitle>
                <CardDescription className="text-white/90">
                  Enter your description and customize your thumbnail
                </CardDescription>
              </CardHeader>
              <CardContent className="pt-6">
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="apiKey" className="flex items-center gap-2">
                      <Key className="h-4 w-4" /> API Key
                    </Label>
                    <Input
                      id="apiKey"
                      placeholder="Enter your OpenAI API key"
                      value={apiKey}
                      onChange={(e) => setApiKey(e.target.value)}
                      type="password"
                      className="w-full"
                      disabled={isLoading}
                    />
                    <p className="text-xs text-gray-500">Your API key is never stored on our servers</p>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="prompt">Description</Label>
                    <Textarea
                      id="prompt"
                      placeholder="Describe your thumbnail (e.g., A professional looking thumbnail with text 'How to Start a YouTube Channel')"
                      value={prompt}
                      onChange={(e) => setPrompt(e.target.value)}
                      className="w-full min-h-[100px]"
                      disabled={isLoading}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="platform">Platform</Label>
                    <Select 
                      value={platform} 
                      onValueChange={handlePlatformChange}
                      disabled={isLoading}
                    >
                      <SelectTrigger id="platform" className="w-full">
                        <SelectValue placeholder="Select platform" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="youtube">YouTube</SelectItem>
                        <SelectItem value="instagram">Instagram</SelectItem>
                        <SelectItem value="facebook">Facebook</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="size">Thumbnail Size</Label>
                    <RadioGroup 
                      value={size} 
                      onValueChange={setSize} 
                      className="flex flex-col space-y-2"
                    >
                      {sizeOptions[platform as keyof typeof sizeOptions].map((option) => (
                        <div key={option.value} className="flex items-center space-x-2">
                          <RadioGroupItem value={option.value} id={option.value} />
                          <Label htmlFor={option.value} className="cursor-pointer">{option.label}</Label>
                        </div>
                      ))}
                    </RadioGroup>
                  </div>
                  
                  <Button 
                    type="submit" 
                    className="w-full bg-gradient-to-r from-purple-500 to-purple-700 text-white hover:from-purple-600 hover:to-purple-800 group transition-all duration-300"
                    disabled={isLoading}
                  >
                    {isLoading ? (
                      <>
                        <Loader className="mr-2 h-4 w-4 animate-spin" />
                        Generating...
                      </>
                    ) : (
                      <>
                        <Image className="mr-2 h-4 w-4 group-hover:animate-pulse" />
                        Generate Thumbnail
                      </>
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
            
            <ResultDisplay 
              result={result} 
              isLoading={isLoading}
              type="image"
            />
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default ThumbnailGenerator;
