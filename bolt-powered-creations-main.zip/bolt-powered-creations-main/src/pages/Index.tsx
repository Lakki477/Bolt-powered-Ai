
import { useNavigate } from 'react-router-dom';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import ToolCard from '@/components/ToolCard';
import { Button } from '@/components/ui/button';
import { Video, Image } from 'lucide-react';

const Index = () => {
  const navigate = useNavigate();

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-purple-50 to-blue-50 py-16 md:py-24">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
            <div>
              <h1 className="text-3xl md:text-5xl font-bold tracking-tighter mb-4">
                Create Amazing Content with AI
              </h1>
              <p className="text-gray-600 md:text-xl max-w-[600px] mb-6">
                Generate creative shayaris, professional bios, trending hashtags, video scripts, thumbnails, and stunning images with our AI-powered tools.
              </p>
              <div className="flex flex-col md:flex-row gap-4">
                <Button 
                  onClick={() => navigate('/signup')} 
                  className="bg-primary hover:bg-primary/90 text-white"
                  size="lg"
                >
                  Get Started Free
                </Button>
                <Button 
                  onClick={() => navigate('/shayari')} 
                  variant="outline" 
                  className="border-primary text-primary hover:bg-primary/10"
                  size="lg"
                >
                  Try Tools
                </Button>
              </div>
            </div>
            <div className="lg:flex justify-end hidden">
              <img 
                src="https://source.unsplash.com/random/800x600/?ai,technology" 
                alt="AI Tools" 
                className="rounded-lg shadow-xl object-cover max-w-full" 
              />
            </div>
          </div>
        </div>
      </section>

      {/* Tools Section */}
      <section className="py-16 bg-white">
        <div className="container px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold">Our Creative Tools</h2>
            <p className="text-gray-600 mt-3 max-w-2xl mx-auto">
              Explore our collection of AI-powered tools designed to help you create amazing content.
            </p>
          </div>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-8">
            <ToolCard 
              title="Shayari Generator" 
              description="Create beautiful, poetic shayaris on any theme with our AI generator." 
              icon={<div className="w-12 h-12 flex items-center justify-center rounded-full bg-purple-100 text-tool-shayari">🎭</div>}
              path="/shayari"
              gradientClass="gradient-shayari"
            />
            
            <ToolCard 
              title="Bio Generator" 
              description="Generate professional and creative bios for your social media profiles." 
              icon={<div className="w-12 h-12 flex items-center justify-center rounded-full bg-cyan-100 text-tool-bio">👤</div>}
              path="/bio"
              gradientClass="gradient-bio"
            />
            
            <ToolCard 
              title="Hashtag Generator" 
              description="Find the perfect hashtags to increase your content's visibility." 
              icon={<div className="w-12 h-12 flex items-center justify-center rounded-full bg-orange-100 text-tool-hashtag">#️⃣</div>}
              path="/hashtag"
              gradientClass="gradient-hashtag"
            />
            
            <ToolCard 
              title="Image Generator" 
              description="Transform your ideas into stunning images with our AI image generator." 
              icon={<div className="w-12 h-12 flex items-center justify-center rounded-full bg-emerald-100 text-tool-image">🖼️</div>}
              path="/image"
              gradientClass="gradient-image"
            />
            
            <ToolCard 
              title="Video Script Generator" 
              description="Create engaging video scripts for YouTube, Instagram and Facebook." 
              icon={<div className="w-12 h-12 flex items-center justify-center rounded-full bg-blue-100 text-blue-600"><Video className="h-6 w-6" /></div>}
              path="/video-script"
              gradientClass="gradient-video"
            />
            
            <ToolCard 
              title="Thumbnail Generator" 
              description="Create eye-catching thumbnails for YouTube, Instagram, and Facebook." 
              icon={<div className="w-12 h-12 flex items-center justify-center rounded-full bg-purple-100 text-purple-600"><Image className="h-6 w-6" /></div>}
              path="/thumbnail"
              gradientClass="gradient-thumbnail"
            />
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-gray-50">
        <div className="container px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold">Why Choose BoltPowered</h2>
            <p className="text-gray-600 mt-3 max-w-2xl mx-auto">
              Our platform offers powerful AI tools that help you create amazing content in seconds.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-lg shadow-md">
              <div className="w-12 h-12 flex items-center justify-center rounded-full bg-purple-100 text-primary mb-4">⚡</div>
              <h3 className="text-xl font-bold mb-2">Lightning Fast</h3>
              <p className="text-gray-600">Generate content in seconds with our optimized AI tools.</p>
            </div>
            
            <div className="bg-white p-8 rounded-lg shadow-md">
              <div className="w-12 h-12 flex items-center justify-center rounded-full bg-blue-100 text-blue-600 mb-4">🎯</div>
              <h3 className="text-xl font-bold mb-2">Highly Accurate</h3>
              <p className="text-gray-600">Our AI models are trained to create relevant and creative content.</p>
            </div>
            
            <div className="bg-white p-8 rounded-lg shadow-md">
              <div className="w-12 h-12 flex items-center justify-center rounded-full bg-green-100 text-green-600 mb-4">🚀</div>
              <h3 className="text-xl font-bold mb-2">Easy to Use</h3>
              <p className="text-gray-600">Simple interface makes it easy to generate the content you need.</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-br from-primary/90 to-blue-600 text-white">
        <div className="container px-4 md:px-6 text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Create Amazing Content?</h2>
          <p className="max-w-2xl mx-auto mb-8 text-white/90">
            Join thousands of users who use our tools to create engaging content every day.
          </p>
          <Button 
            onClick={() => navigate('/signup')} 
            size="lg"
            className="bg-white text-primary hover:bg-gray-100"
          >
            Get Started Free
          </Button>
        </div>
      </section>
      
      <Footer />
    </div>
  );
};

export default Index;
