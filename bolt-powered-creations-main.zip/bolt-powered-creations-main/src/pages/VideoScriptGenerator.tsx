
import { useState } from 'react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import ResultDisplay from '@/components/ResultDisplay';
import { generateVideoScript } from '@/services/api';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from "sonner";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Video } from 'lucide-react';

const VideoScriptGenerator = () => {
  const [topic, setTopic] = useState('');
  const [platform, setPlatform] = useState('youtube');
  const [scriptType, setScriptType] = useState('short');
  const [result, setResult] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!topic.trim()) {
      toast.error("Please enter a topic for your video script");
      return;
    }
    
    setIsLoading(true);
    
    try {
      const script = await generateVideoScript(topic, platform, scriptType);
      setResult(script);
      toast.success("Video script generated successfully!");
    } catch (error) {
      console.error('Error generating video script:', error);
      toast.error("Failed to generate video script. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      
      <main className="flex-1 py-12 bg-gradient-to-b from-blue-50 to-white">
        <div className="container px-4 md:px-6">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-8">
              <h1 className="text-3xl font-bold text-gray-900">Video Script Generator</h1>
              <p className="text-gray-600 mt-2">
                Create engaging video scripts for YouTube, Instagram, or Facebook.
              </p>
            </div>
            
            <Card className="border shadow-md">
              <CardHeader className="bg-gradient-to-r from-blue-500 to-blue-700 text-white">
                <CardTitle className="flex items-center gap-2">
                  <Video className="h-6 w-6" />
                  Create Video Script
                </CardTitle>
                <CardDescription className="text-white/90">
                  Enter your topic and customize your script
                </CardDescription>
              </CardHeader>
              <CardContent className="pt-6">
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="topic">Topic</Label>
                    <Textarea
                      id="topic"
                      placeholder="Enter your video topic (e.g., Introduction to Machine Learning)"
                      value={topic}
                      onChange={(e) => setTopic(e.target.value)}
                      className="w-full min-h-[100px]"
                      disabled={isLoading}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="platform">Platform</Label>
                    <Select 
                      value={platform} 
                      onValueChange={setPlatform}
                      disabled={isLoading}
                    >
                      <SelectTrigger id="platform" className="w-full">
                        <SelectValue placeholder="Select platform" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="youtube">YouTube</SelectItem>
                        <SelectItem value="instagram">Instagram</SelectItem>
                        <SelectItem value="facebook">Facebook</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Script Length</Label>
                    <RadioGroup 
                      value={scriptType} 
                      onValueChange={setScriptType} 
                      className="flex space-x-4"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="short" id="short" />
                        <Label htmlFor="short" className="cursor-pointer">Short (30-60 seconds)</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="long" id="long" />
                        <Label htmlFor="long" className="cursor-pointer">Long (3-5 minutes)</Label>
                      </div>
                    </RadioGroup>
                  </div>
                  
                  <Button 
                    type="submit" 
                    className="w-full bg-gradient-to-r from-blue-500 to-blue-700 text-white hover:from-blue-600 hover:to-blue-800"
                    disabled={isLoading}
                  >
                    {isLoading ? 'Generating...' : 'Generate Script'}
                  </Button>
                </form>
              </CardContent>
            </Card>
            
            <ResultDisplay 
              result={result} 
              isLoading={isLoading}
              type="video"
            />
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default VideoScriptGenerator;
