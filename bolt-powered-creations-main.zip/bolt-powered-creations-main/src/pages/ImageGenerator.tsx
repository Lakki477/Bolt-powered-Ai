
import { useState } from 'react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import ResultDisplay from '@/components/ResultDisplay';
import { generateImage } from '@/services/api';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from "sonner";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from '@/components/ui/label';
import { Download, Image as ImageIcon, Key, Loader } from 'lucide-react';
import { Input } from '@/components/ui/input';

const DEFAULT_API_KEY = "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";

const ImageGenerator = () => {
  const [prompt, setPrompt] = useState('');
  const [result, setResult] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [size, setSize] = useState('800x600');
  const [apiKey, setApiKey] = useState(DEFAULT_API_KEY);
  const [downloading, setDownloading] = useState(false);
  const [showApiInput, setShowApiInput] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!prompt.trim()) {
      toast.error("Please enter a description for your image");
      return;
    }
    
    // Validate API key if provided
    if (!apiKey.trim()) {
      toast.error("API key is required for image generation");
      return;
    }

    setIsLoading(true);
    
    try {
      const imageUrl = await generateImage(prompt, size, apiKey.trim());
      setResult(imageUrl);
      toast.success("Image generated successfully!");
    } catch (error) {
      console.error('Error generating image:', error);
      toast.error("Failed to generate image. Please check your API key and try again.");
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleDownload = async () => {
    if (!result) return;
    
    setDownloading(true);
    
    try {
      const response = await fetch(result);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `generated-image-${Date.now()}.jpg`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      toast.success("Image downloaded successfully!");
    } catch (error) {
      console.error('Error downloading image:', error);
      toast.error("Failed to download image. Please try again.");
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      
      <main className="flex-1 py-12 bg-gradient-to-b from-emerald-50 to-white">
        <div className="container px-4 md:px-6">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-8">
              <h1 className="text-3xl font-bold text-gray-900">Image Generator</h1>
              <p className="text-gray-600 mt-2">
                Transform your ideas into stunning images with our AI image generator.
              </p>
            </div>
            
            <Card className="border shadow-md">
              <CardHeader className="bg-gradient-to-r from-emerald-500 to-emerald-700 text-white">
                <CardTitle className="flex items-center gap-2">
                  <ImageIcon className="h-6 w-6" />
                  Generate an Image
                </CardTitle>
                <CardDescription className="text-white/90">
                  Describe the image you want to create
                </CardDescription>
              </CardHeader>
              <CardContent className="pt-6">
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="prompt">Image Description</Label>
                    <Textarea
                      id="prompt"
                      placeholder="Describe your image in detail (e.g., a mountain landscape at sunset with clouds)"
                      value={prompt}
                      onChange={(e) => setPrompt(e.target.value)}
                      className="w-full min-h-[120px]"
                      disabled={isLoading}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <Label htmlFor="apiKey" className="flex items-center gap-2">
                        <Key className="h-4 w-4" />
                        OpenAI API Key
                      </Label>
                      <Button 
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => setShowApiInput(!showApiInput)}
                        className="text-xs"
                      >
                        {showApiInput ? "Hide" : "Change"}
                      </Button>
                    </div>
                    
                    {showApiInput ? (
                      <Input
                        id="apiKey"
                        type="password"
                        placeholder="sk-..."
                        value={apiKey}
                        onChange={(e) => setApiKey(e.target.value)}
                        className="w-full font-mono"
                        disabled={isLoading}
                      />
                    ) : (
                      <div className="bg-gray-100 border border-gray-300 rounded px-3 py-2 text-gray-700 font-mono text-sm">
                        {apiKey.substring(0, 8)}...{apiKey.substring(apiKey.length - 4)}
                      </div>
                    )}
                    
                    <p className="text-xs text-gray-500">
                      Your API key is never stored on our servers
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="size">Image Size</Label>
                    <Select 
                      value={size} 
                      onValueChange={setSize}
                      disabled={isLoading}
                    >
                      <SelectTrigger id="size" className="w-full">
                        <SelectValue placeholder="Select image size" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="256x256">256 x 256</SelectItem>
                        <SelectItem value="512x512">512 x 512 (Square)</SelectItem>
                        <SelectItem value="800x600">800 x 600</SelectItem>
                        <SelectItem value="1024x768">1024 x 768</SelectItem>
                        <SelectItem value="1024x1024">1024 x 1024 (Square)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="flex gap-3 mt-6">
                    <Button 
                      type="submit" 
                      className="flex-1 bg-gradient-to-r from-emerald-500 to-emerald-700 text-white hover:from-emerald-600 hover:to-emerald-800 transition-all duration-300 relative overflow-hidden group"
                      disabled={isLoading}
                    >
                      {isLoading ? (
                        <>
                          <span className="absolute inset-0 w-full h-full bg-gradient-to-r from-emerald-400 to-emerald-600 opacity-20 animate-pulse"></span>
                          <Loader className="mr-2 h-4 w-4 animate-spin" />
                          Generating...
                        </>
                      ) : (
                        <>
                          <span className="absolute top-0 left-0 w-full h-full bg-gradient-to-r from-emerald-300/20 to-transparent transform -translate-x-full group-hover:translate-x-0 transition-transform duration-700"></span>
                          <ImageIcon className="mr-2 h-4 w-4 group-hover:scale-110 transition-transform duration-300" />
                          Generate Image
                        </>
                      )}
                    </Button>
                    
                    {result && (
                      <Button 
                        type="button" 
                        variant="outline"
                        className="bg-white text-emerald-700 border-emerald-500 hover:bg-emerald-50 transition-all duration-300 relative overflow-hidden group"
                        disabled={downloading || isLoading}
                        onClick={handleDownload}
                      >
                        {downloading ? (
                          <Loader className="h-4 w-4 animate-spin" />
                        ) : (
                          <>
                            <span className="absolute inset-0 bg-emerald-100/50 transform scale-x-0 group-hover:scale-x-100 transition-transform origin-left duration-300"></span>
                            <Download className="h-4 w-4 group-hover:animate-bounce transition-all duration-300" />
                          </>
                        )}
                        <span className="ml-2 relative z-10">Download</span>
                      </Button>
                    )}
                  </div>
                </form>
              </CardContent>
            </Card>
            
            {(isLoading || result) && (
              <ResultDisplay 
                result={result} 
                isLoading={isLoading}
                type="image"
              />
            )}
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default ImageGenerator;
