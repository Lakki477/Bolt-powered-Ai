
import { useState } from 'react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import ResultDisplay from '@/components/ResultDisplay';
import { generateShayari } from '@/services/api';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from "sonner";

const ShayariGenerator = () => {
  const [theme, setTheme] = useState('');
  const [result, setResult] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!theme.trim()) {
      toast.error("Please enter a theme for your shayari");
      return;
    }
    
    setIsLoading(true);
    
    try {
      const shayari = await generateShayari(theme);
      setResult(shayari);
    } catch (error) {
      console.error('Error generating shayari:', error);
      toast.error("Failed to generate shayari. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      
      <main className="flex-1 py-12 bg-gradient-to-b from-purple-50 to-white">
        <div className="container px-4 md:px-6">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-8">
              <h1 className="text-3xl font-bold text-gray-900">Shayari Generator</h1>
              <p className="text-gray-600 mt-2">
                Create beautiful, heartfelt shayaris on any theme with our AI generator.
              </p>
            </div>
            
            <Card className="border shadow-md">
              <CardHeader className="bg-gradient-to-r from-purple-500 to-purple-700 text-white">
                <CardTitle>Generate a Shayari</CardTitle>
                <CardDescription className="text-white/90">
                  Enter a theme, emotion, or occasion for your shayari
                </CardDescription>
              </CardHeader>
              <CardContent className="pt-6">
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Input
                      placeholder="Enter theme (e.g., love, friendship, rain)"
                      value={theme}
                      onChange={(e) => setTheme(e.target.value)}
                      className="w-full"
                      disabled={isLoading}
                    />
                  </div>
                  
                  <Button 
                    type="submit" 
                    className="w-full bg-gradient-to-r from-purple-500 to-purple-700 text-white hover:from-purple-600 hover:to-purple-800"
                    disabled={isLoading}
                  >
                    {isLoading ? 'Generating...' : 'Generate Shayari'}
                  </Button>
                </form>
              </CardContent>
            </Card>
            
            <ResultDisplay 
              result={result} 
              isLoading={isLoading}
              type="shayari"
            />
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default ShayariGenerator;
